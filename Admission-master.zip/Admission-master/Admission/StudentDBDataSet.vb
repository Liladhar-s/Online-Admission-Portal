﻿Imports Admission

Partial Class StudentDBDataSet
    Public Property TableAdapters As Object

    Friend Sub Update(studentDBDataSet As StudentDBDataSet)
        Throw New NotImplementedException()
    End Sub
End Class

Namespace StudentDBDataSetTableAdapters
    Partial Public Class stu_tableTableAdapter
    End Class
End Namespace
